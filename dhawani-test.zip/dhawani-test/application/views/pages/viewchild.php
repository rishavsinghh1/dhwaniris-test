<div class="container">
	<section class="py">
		
		<div class="row">
	     <div class="col-md-1"></div>
	    <div class="col-md-8">
	    <div class="card child-details">
		  <div class="card-body">
		   <div class="row">
		  		<div class="col-sm-3"><a href="<?=base_url()?>child"><i class="fa fa-arrow-left"></i></a></div> 
		    	
		  	</div>
		  	 <img src="<?=base_url()?>uploads/<?=(!empty($childdata[0]->image))? $childdata[0]->image:'default.png' ?>" style="width: 100px;height: 100px;" alt="..." class="rounded-circle">

		  	 <div class="row mt-4">
		  	 	<div class="col">
		  	 		<span> <b>Name :</b><?=ucfirst($childdata[0]->child_name)?></span>
		  	 	</div>
		  	 	<div class="col">
		  	 		<span> <b>Sex :</b> <?=ucfirst(($childdata[0]->gender ==='m')?'Male':'Female')?></span>
		  	 	</div>
		  	 	<div class="col">
		  	 		<span> <b>Date Of Birth :</b><?=date("d/m/Y", strtotime($childdata[0]->dob))?></span>
		  	 	</div> 
		  	 </div>
		  	 <div class="row mt-4">
		  	 	<div class="col">
		  	 		<span> <b>Father's Name :</b><?=ucfirst($childdata[0]->father_name)?></span>
		  	 	</div>
		  	 	<div class="col">
		  	 		<span> <b>Mother's Name :</b> <?=ucfirst($childdata[0]->mother_name)?></span>
		  	 	</div>
		  	 	<div class="col">
		  	 		<span> <b>State :</b> <?=ucfirst($childdata[0]->state)?></span>
		  	 	</div> 
		  	 </div>
		  	 <div class="row mt-4">
		  	 	<div class="col">
		  	 		<span> <b>District :</b> <?=ucfirst($childdata[0]->district_name)?></span>
		  	 	</div> 
		  	 </div>
		  </div>
		</div>
	    </div>
	       <div class="col-md-1"></div>
	  </div>
		
	</section>
</div>