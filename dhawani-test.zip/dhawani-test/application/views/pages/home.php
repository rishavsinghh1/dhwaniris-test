<section class="py">
	<div class="container">
		<div class="row">
			<div class="col-md-12">
				<div class="card">
					<div class="card-body">
						<div class="row">
							<div class="col-sm-4">
								<span class="font"><b>Name:</b>  Ramesh Prakash</span>
							</div>
							<div class="col-sm-4">
								<span class="font"><b>Organisation:</b>  Bal Vikash</span>
							</div>
							<div class="col-sm-4">
								<span class="font"><b>Designation:</b>  Cluster Cordinator</span>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</section>
<section class="py1">
	<div class="container">
		<div class="card">
			<img class="card-img" src="https://dhwaniris.in/wp-content/uploads/2018/10/IIMPACT.jpg" alt="">
			
		</div>
	</div>
</section>