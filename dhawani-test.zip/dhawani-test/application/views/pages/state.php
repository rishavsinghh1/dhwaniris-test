<section class="py">
	<div class="container">  
				<div class="row">
						  <div class="col-sm-4">
						    <div class="card card-color">
						      <div class="card-body"> 
						           <div class="col-sm-12">
						           	<div class="row">
						           		<div class="d-inline-block my-2 w-100 show-error">
                                            </div>
						           	<div class="col-sm-4">
						           		<div class="circle"><i class="fa fa-plus"></i></div>
						           	</div>
						           	<div class="col-sm-8">
						           		<form id="form_state" method="POST" accept-charset="utf-8">  
						           		<input type="text" class="form-control username" placeholder="Enter State Name" name="state" >
						           		<button style="margin-top: 8px ;" id="add" class="btn btn-sm btn-green" type="submit">ADD STATE</button>
						           		</form>
						           	</div>
						           </div>
						       </div>
						      </div>
						    </div>
						  </div> 
						  <?php if (is_array($state) || is_object($state)):?>
						  <?php $n=1; foreach ($state as $key => $value): ?>
						  <div class="col-sm-4">
						    <div class="card card-color">
						      <div class="card-body"> 
						           	<div class="row">
							           	<div class="col-sm-3">
							           		<div class="circle circel-solid"><?=$n?></div>
							           	</div>
							           	<div class="col-sm-6 top-margin">
							           		<h5><?=$value->state?></h5>
							           	</div>
							           	<div class="col-sm-3 top-margin">
							           		<span class="arrow">
							           			<i class="fa fa-arrow-right"></i>
							           		</span>
							           	</div>
						           </div>
						      </div>
						    </div>  
						  </div>
						<?php $n++; endforeach;?> 
						<?php endif;?>
					    </div> 
 
</section>