<div class="container">
	<section class="py">
		
		<div class="row">
	    <div class="col">
	      
	    </div>
	    <div class="col">
	    <div class="card" style="width: 18rem;">
		  <div class="card-body">
		  	<div class="row">
		  		<div class="col-sm-3"><a href="<?=base_url()?>child"><i class="fa fa-arrow-left"></i></a></div> 
		    	<div class="col-sm-6"><h5 class="card-title d-flex justify-content-center">ADD CHILD</h5> </div>
		  	</div>
		  	<div class="d-inline-block my-2 w-100 show-error">
				</div>
		     <form id="form_add_child" method="POST" accept-charset="utf-8" enctype="multipart/form-data">
		     	 <div class="form-group"> 
                    <input type="text" name="name" placeholder="Name" class="form-control border-none" id="">
                 </div>
                 <div class="form-group"> 
				    <select class="form-control" name="gender" id="exampleFormControlSelect1">
				      <option value=" ">Sex</option>
				      <option value="m">Male</option>
				      <option value="f">Female</option> 
				    </select>
				  </div>
				  <div class="form-group"> 
                    <input type="date" name="dob" placeholder="Date Of Birth" class="form-control" id="">
                 </div>
                 <div class="form-group"> 
                    <input type="text" name="fathername" placeholder="Father Name" class="form-control" id="">
                 </div>
                 <div class="form-group"> 
                    <input type="text" name="mothername" placeholder="Mother Name" class="form-control" id="">
                 </div>
                 <div class="form-group"> 
				   <select class="form-control" name="state" id="selectstate">
				      <option value=" ">State</option>
				     <?=$state?> 
				    </select>
				  </div>
				  <div class="form-group"> 
				    <select class="form-control" name="district" id="selectdistrict">
				      <option value=" ">District</option>
				       
				    </select>
				  </div>
				  <div class="custom-file">
				  <input type="file" name="childimage" class="custom-file-input" id="customFileLangHTML">
				  <label class="custom-file-label" for="customFileLangHTML">Take a Photo/ Upload</label>
				</div>
				<div class="form-group" style="margin-top: 1rem !important;"> 
				<button type="submit" class="btn btn-green btn-block add">Submit</button>
			</div>
		     </form>
		  </div>
		</div>
	    </div>
	     <div class="col">
	       
	    </div>
	  </div>
		
	</section>
</div>