<style type="text/css" media="screen">
	ul li {
		padding: 7px;
		margin: 0px 20px;
		font-weight: 600;
	}
	.font {
		font-size: 19px!important;
	}
	.card-img {
		height: 400px;
	}
	.card-none {
		border: none;
	}
	.card-color{
		border: 1px solid rgb(13 126 57);
	}
	.child-details {
		width: 962px;
		height: 416px
	}
	ul li {
		padding: 7px;
		margin: 0px 20px;
		font-weight: 600;
	}
	.py {
		padding-top: 8rem !important;
	}
	.py1 {
		padding-top: 1rem !important;
	}
	.font {
		font-size: 19px!important;
	}
	.btn-green {
		color: #fff;
		background-color: #0d7e39;
		border-color: #0d7e39;
	}
	.circle {
		width: 75px;
		height: 75px;
		line-height: 75px;
		border-radius: 50%;
		/* the magic */
		border-style: dotted;
		-moz-border-radius: 50%;
		-webkit-border-radius: 50%;
		text-align: center;
		color: black;
		font-size: 16px;
		text-transform: uppercase;
		margin: 0 auto 40px;
	}
	.circel-solid {
		border: 2px solid green;
		font-weight: 600 !important;
		font-size: 1.8rem !important;
		color: green;
	}
	.circle .fa {
		font-weight: 100 !important;
		font-size: 20px;
		-webkit-text-stroke: 2px white;
	}
	.top-margin {
		margin-top: 30px;
		text-align: center;
		color: green;
	}
	.top-margin .fa {
		font-size: 1.5rem;
	}
	.form-control:focus {
		border-color: inherit;
		-webkit-box-shadow: none;
		box-shadow: none;
	}
	.form-control {
		border: none;
		border-bottom: 1px solid #e7e7e7;
	}
	.card-title {
		color: #0d7e39;
	}
	a .fa {
		color: #0d7e39 !important;
	}
	.card {
		margin-bottom: 10px;
	}
	.arrow {
		cursor: pointer;
	}	


	
</style>