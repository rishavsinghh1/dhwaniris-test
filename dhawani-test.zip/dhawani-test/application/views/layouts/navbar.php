		<nav class="navbar navbar-expand-lg fixed-top shadow navbar-light bg-white" id="topnav">
			<div class="container">
				<div class="d-flex align-items-center"><a class="navbar-brand py-1" href="<?=base_url()?>home"><img src="<?=base_url()?>assest/images/logo.png" width="56" height="56" alt="Directory logo"></a>
			</div>
			<button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarCollapse" aria-controls="navbarCollapse" aria-expanded="false" aria-label="Toggle navigation"><i class="fa fa-bars"></i></button>
			<!-- Navbar Collapse -->
			<div class="collapse navbar-collapse" id="navbarCollapse">
				
				<ul class="navbar-nav ml-auto">
					<li class="nav-item nav-padding"><a class="nav-link" href="<?=base_url()?>home">Home</a>
				</li>
				
				<li class="nav-item nav-padding"><a class="nav-link" href="<?=base_url()?>state">State</a></li>
				<li class="nav-item nav-padding"><a class="nav-link" href="<?=base_url()?>district">District</a></li>
				<li class="nav-item nav-padding"><a class="nav-link" href="<?=base_url()?>child">Child</a></li>
				<li class="nav-item nav-padding"><a class="nav-link"href="javascript:void(0);" id="logout"> <i class="fa fa-power-off"></i> Logout</a> </li>
			</ul>
		</div>
	</div>
</nav>