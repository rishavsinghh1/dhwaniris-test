<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Validation_user
{
	public function __construct(){
		$CI =& get_instance();
		$CI->load->database();
	}

	public function getLoginDetails($user){
		$CI =& get_instance();   
	    $details = $CI->db->select('*')->from('tbl_login')->where(array('id'=>$user))->get();
	     if($details->num_rows() > 0){
	        $data = $details->row_array();
	        $newdata = array(
        	    'username'  => $data['username'], 
        	    'token'  => $data['token'],
                'is_active'  => $data['is_active'],
                'last_login'=> strtotime($data['last_login']),
        	    'is_loggin' => TRUE
		    );
		    return $newdata;
	     }else{
	        return false;
	    } 
		 return false;
		}

	public function  checkHeader($data){
		$CI =& get_instance();		
		$CI->load->library('session');
		if($CI->session->userdata('userDeails')){
			$token = $CI->session->userdata('userDeails')['token'];
			if($data['token'] == $token){
				return true;
			}else{
				return false;
			}
		}else{
			return false;
		}
	}
}
 