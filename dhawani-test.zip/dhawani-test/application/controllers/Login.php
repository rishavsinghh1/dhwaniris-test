<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Login extends CI_Controller {
    public function __construct()
    {
    	parent::__construct();
    	$this->load->model(array('authmodel'=>'auth'));
        $this->load->library(array('Validation_user'=>'valid'));
        $this->response = array();
    }
	public function authorize()
	{
	 	$this->form_validation->set_rules('username', 'Username', 'trim|required');
	 	$this->form_validation->set_rules('password', 'Password', 'trim|required');
		if ($this->form_validation->run() == TRUE) { 
			$data = [
        		'username' => $this->input->post('username'),
        		'password' => md5($this->input->post('password')),
        	];
        	$login = $this->auth->login($data);
        	if($login){ 
	        		$valid = $this->valid->getLoginDetails($login['id']);
	        		if($valid){
                        $this->session->set_userdata("userDeails",$valid);
	        			$this->response['status']     =   1;
	            		$this->response['statuscode'] =   200;
	            		$this->response['message']    =   "Successfully Login";
                        $this->response['data']       =    $valid;
	        		}else{
	        			$this->response['status']     =   0;
	            		$this->response['statuscode'] =   403;
	            		$this->response['message']    =   "User Details Not Valid!!";
	        		} 
        	}else{
        		$this->response['status']     =   0;
            	$this->response['statuscode'] =   405;
            	$this->response['message']    =   "User Not Found!!..";
        	}
         }else{
        	$this->form_validation->set_error_delimiters('', '');
            $this->response['status']     =   0;
            $this->response['statuscode'] =   406;
            $this->response['message']    =   validation_errors();
        }
       echo json_encode($this->response, JSON_UNESCAPED_SLASHES);
	}
    public function logout(){  
       $data = $this->input->request_headers();
        if(array_key_exists('token',$data)){
            $check = $this->valid->checkHeader($data);
            if($check){
                $this->session->sess_destroy();
                $this->response['status']     =   1;
                $this->response['statuscode'] =   200;
                $this->response['message']    =   "Successfully Logout";
            }else{
                $this->response['status']     =   0;
                $this->response['statuscode'] =   404;
                $this->response['message']    =   "Invalid Token !! Please Check Again";
            }
        }else{
            $this->response['status']     =   0;
            $this->response['statuscode'] =   404;
            $this->response['message']    =   "Unknown header request!!";
        }
       //
       echo json_encode($this->response, JSON_UNESCAPED_SLASHES);
    }

}

/* End of file Login.php */
/* Location: ./application/controllers/Login.php */