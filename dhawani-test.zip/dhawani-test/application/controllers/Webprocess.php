<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Webprocess extends CI_Controller {
	public function __construct()
	{
		parent::__construct();
		$this->load->model(array('webmodel'=>'web'));
        $this->load->library(array('Validation_user'=>'valid'));
        $this->time = strtotime(date('H:i:s'));
		$this->response = array();
	}
	public function add_state(){
       $data = $this->input->request_headers();
        if(array_key_exists('token',$data)){
            $check = $this->valid->checkHeader($data);
            if($check){
	    $this->form_validation->set_rules('state', 'State', 'trim|required'); 
		if ($this->form_validation->run() == TRUE) { 
			$data = [
        		'state' => $this->input->post('state') 
        	];
            $checkState = $this->web->getState(array('state'=>$data['state']));
            if(!$checkState){
        	$state = $this->web->state($data);
        	 if($state){  
        		    $this->response['status']     =   1;
            		$this->response['statuscode'] =   200;
            		$this->response['message']    =   "Successfully Added";
        		}else{
        			$this->response['status']     =   0;
            		$this->response['statuscode'] =   404;
            		$this->response['message']    =   "Some Problem Occured!!";
        		}
            }else{
                $this->response['status']     =   0;
                $this->response['statuscode'] =   404;
                $this->response['message']    =   "state already exists!!";
            }
         }else{
        	$this->form_validation->set_error_delimiters('', '');
            $this->response['status']     =   0;
            $this->response['statuscode'] =   406;
            $this->response['message']    =   validation_errors();
        }
        }else{
                $this->response['status']     =   0;
                $this->response['statuscode'] =   404;
                $this->response['message']    =   "Invalid Token or you are Logout !! Please Check Again";
            }
        }else{
            $this->response['status']     =   0;
            $this->response['statuscode'] =   404;
            $this->response['message']    =   "Unknown header request!!";
        }
       echo json_encode($this->response, JSON_UNESCAPED_SLASHES);
	} 
    public function add_district(){
       $data = $this->input->request_headers();
        if(array_key_exists('token',$data)){
            $check = $this->valid->checkHeader($data);
            if($check){
        $this->form_validation->set_rules('state_id', 'State', 'trim|required');
        $this->form_validation->set_rules('district_name', 'district', 'trim|required'); 
        if ($this->form_validation->run() == TRUE) { 
            $data = [
                'state_id' => $this->input->post('state_id'),
                'name' => $this->input->post('district_name')
            ];
            $checkDistrict = $this->web->getdisrtict(array('search'=>$data['name']));
            if(!$checkDistrict){
                $state = $this->web->disrtict($data);
                if($state){  
                    $this->response['status']     =   1;
                    $this->response['statuscode'] =   200;
                    $this->response['message']    =   "Successfully District Added";
                }else{
                    $this->response['status']     =   0;
                    $this->response['statuscode'] =   404;
                    $this->response['message']    =   "Some Problem Occured!!";
                }
            }else{
                $this->response['status']     =   0;
                $this->response['statuscode'] =   404;
                $this->response['message']    =   "District Already Exists!!";
            }
         }else{
            $this->form_validation->set_error_delimiters('', '');
            $this->response['status']     =   0;
            $this->response['statuscode'] =   406;
            $this->response['message']    =   validation_errors();
        }
        }else{
                $this->response['status']     =   0;
                $this->response['statuscode'] =   404;
                $this->response['message']    =   "Invalid Token or you are Logout !! Please Check Again";
            }
        }else{
            $this->response['status']     =   0;
            $this->response['statuscode'] =   404;
            $this->response['message']    =   "Unknown header request!!";
        }
       echo json_encode($this->response, JSON_UNESCAPED_SLASHES);
    }
    public function addchild(){
      $data = $this->input->request_headers();
        if(array_key_exists('token',$data)){
            $check = $this->valid->checkHeader($data);
            if($check){
      $this->form_validation->set_rules('name', 'Name', 'trim|required'); 
      $this->form_validation->set_rules('gender', 'Gender', 'trim|required');
      $this->form_validation->set_rules('dob', 'Date Of Birth', 'trim|required');
      $this->form_validation->set_rules('fathername', 'Father Name', 'trim|required');
      $this->form_validation->set_rules('mothername', 'Mother Name', 'trim|required');
      $this->form_validation->set_rules('state', 'State Name', 'trim|required');
      $this->form_validation->set_rules('district', 'State Name', 'trim|required');
      $this->form_validation->set_rules('childimage', 'Choose Picture', 'trim');
        if ($this->form_validation->run() == TRUE) { 
                 if(!empty($_FILES['childimage']['name'])){
                $config['upload_path'] = './uploads/';
                $config['allowed_types'] = 'jpg|jpeg|png|gif';
                $config['file_name'] = $_FILES['childimage']['name'];
                 $config['encrypt_name'] = TRUE; 
                $this->load->library('upload',$config);
                $this->upload->initialize($config); 
                if($this->upload->do_upload('childimage')){
                    $uploadData = $this->upload->data();
                    $childimage = $uploadData['file_name'];
                }else{
                    $childimage = '';
                }
            }else{
                $childimage = '';
            } 
            $data = [
                'name' => $this->input->post('name'),
                'gender' => $this->input->post('gender'),
                'dob' => $this->input->post('dob'),
                'father_name' => $this->input->post('fathername'),
                'mother_name' => $this->input->post('mothername'),
                'state' => $this->input->post('state'),
                'district' => $this->input->post('district'),
                'image' =>$childimage
            ];
            $child = $this->web->addchild($data);
             if($child){ 
                    $this->response['status']     =   1;
                    $this->response['statuscode'] =   200;
                    $this->response['message']    =   "Successfully Added";
                }else{
                    $this->response['status']     =   0;
                    $this->response['statuscode'] =   403;
                    $this->response['message']    =   "Some Problem Occured!!";
                } 
         }else{
            $this->form_validation->set_error_delimiters('', '');
            $this->response['status']     =   0;
            $this->response['statuscode'] =   406;
            $this->response['message']    =   validation_errors();
        }
         }else{
                $this->response['status']     =   0;
                $this->response['statuscode'] =   404;
                $this->response['message']    =   "Invalid Token or you are Logout !! Please Check Again";
            }
        }else{
            $this->response['status']     =   0;
            $this->response['statuscode'] =   404;
            $this->response['message']    =   "Unknown header request!!";
        }
       echo json_encode($this->response, JSON_UNESCAPED_SLASHES);
    }
    public function getstate(){
       $data = $this->input->request_headers();
        if(array_key_exists('token',$data)){
            $check = $this->valid->checkHeader($data);
            if($check){
               $data = $this->web->getState();
               if($data){
                    $this->response['status']       =   1;
                    $this->response['statuscode']   =   200;
                    $this->response['timestamp']    =   $this->time;
                    $this->response['message']      =   "State Found";
                    $this->response['state']        =   $data;
               }else{
                    $this->response['status']     =   0;
                    $this->response['statuscode'] =   404;
                    $this->response['message']    =   "No State Found";
               }
            }else{
                $this->response['status']     =   0;
                $this->response['statuscode'] =   404;
                $this->response['message']    =   "Invalid Token or you are Logout !! Please Check Again";
            }
        }else{
            $this->response['status']     =   0;
            $this->response['statuscode'] =   404;
            $this->response['message']    =   "Unknown header request!!";
        }
       //
       echo json_encode($this->response, JSON_UNESCAPED_SLASHES);
    }
    public function getdistrict(){
       $data = $this->input->request_headers();
        if(array_key_exists('token',$data)){
            $check = $this->valid->checkHeader($data);
            if($check){
               $id = (!empty($this->input->get('state_id')))?$this->input->get('state_id'):null;
               $data = $this->web->getdisrtict(array('search'=>$id));

               if($data){
                    $this->response['status']       =   1;
                    $this->response['statuscode']   =   200;
                    $this->response['timestamp']    =   $this->time;
                    $this->response['message']      =   "District Found";
                    $this->response['district']     =   $data;
               }else{
                    $this->response['status']     =   0;
                    $this->response['statuscode'] =   404;
                    $this->response['message']    =   "No District Found";
               }
            }else{
                $this->response['status']     =   0;
                $this->response['statuscode'] =   404;
                $this->response['message']    =   "Invalid Token or you are Logout !! Please Check Again";
            }
        }else{
            $this->response['status']     =   0;
            $this->response['statuscode'] =   404;
            $this->response['message']    =   "Unknown header request!!";
        }
       //
       echo json_encode($this->response, JSON_UNESCAPED_SLASHES);
    }
    public function getchildprofile(){
       $data = $this->input->request_headers();
        if(array_key_exists('token',$data)){
            $check = $this->valid->checkHeader($data);
            if($check){
               $data = $this->web->getchild();
               if($data){
                    $this->response['status']       =   1;
                    $this->response['statuscode']   =   200;
                    $this->response['timestamp']    =   $this->time;
                    $this->response['message']      =   "Child Profile Detail Found";
                    $this->response['child_profile']=   $data;
               }else{
                    $this->response['status']     =   0;
                    $this->response['statuscode'] =   404;
                    $this->response['message']    =   "No Child Profile Detail Found";
               }
            }else{
                $this->response['status']     =   0;
                $this->response['statuscode'] =   404;
                $this->response['message']    =   "Invalid Token or you are Logout !! Please Check Again";
            }
        }else{
            $this->response['status']     =   0;
            $this->response['statuscode'] =   404;
            $this->response['message']    =   "Unknown header request!!";
        }
       //
       echo json_encode($this->response, JSON_UNESCAPED_SLASHES);
    }

}

/* End of file Webprocess.php */
/* Location: ./application/controllers/Webprocess.php */